//
//  PNChannelHistoryParser.h
// 
//
//  Created by moonlight on 1/22/13.
//
//


#import <Foundation/Foundation.h>
#import "PNResponseParser.h"


@interface PNChannelHistoryParser : PNResponseParser


@end