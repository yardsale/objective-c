//
//  PNTimeTokenResponseParser.h
// 
//
//  Created by moonlight on 1/15/13.
//
//


#import <Foundation/Foundation.h>
#import "PNResponseParser.h"


@interface PNTimeTokenResponseParser : PNResponseParser


@end